package common;

public interface ExceptionHandler {
    void handleException(Exception e);
}
