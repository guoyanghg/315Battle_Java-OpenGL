package Abstract;

public class weapon {

}
